package com.apisul.apisulelevatorsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApisulElevatorsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
